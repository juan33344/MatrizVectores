
import numpy as np

def multiplicar_matrices(mat1, mat2):
    if len(mat1[0]) != len(mat2):
        print("Las matrices no son multiplicables")
        return None
    
    MatMulti = np.zeros((len(mat1), len(mat2[0])))
    
    for i in range(len(mat1)):
        for j in range(len(mat2[0])):
            for k in range(len(mat2)):
                MatMulti[i][j] += mat1[i][k] * mat2[k][j]
    
    return MatMulti.astype(int)

# Ejemplo
A = np.array([[1, 2, 3],
              [4, 5, 6]])

B = np.array([[7, 8],
              [9, 10],
              [11, 12]])

print("Matriz A:")
print(A)
print("\nMatriz B:")
print(B)

resultado = multiplicar_matrices(A, B)
if resultado is not None:
    print("\nResultado A x B:")
    print(resultado)
