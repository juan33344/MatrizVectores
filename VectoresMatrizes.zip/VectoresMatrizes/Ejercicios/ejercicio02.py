import numpy as np

def generar_cuadrado_magico_3x3():
    """
    Genera un cuadrado mágico 3x3 usando el Método Siamés:
    1. Empezar con 1 en el centro de la primera fila [0,1]
    2. Moverse diagonal arriba-derecha
    3. Si se sale de límites: usar wrap-around (%)
    4. Si la casilla está ocupada: ir directamente abajo
    """
    # Inicializar matriz 3x3 con NumPy
    cuadrado = np.zeros((3, 3), dtype=int)
    
    # Posición inicial: centro de primera fila
    fila, col = 0, 1
    
    # Colocar números del 1 al 9
    for num in range(1, 10):
        cuadrado[fila][col] = num
        
        # Siguiente posición: diagonal arriba-derecha
        nueva_fila = (fila - 1) % 3
        nueva_col = (col + 1) % 3
        
        # Si está ocupada, ir abajo de la posición actual
        if cuadrado[nueva_fila][nueva_col] != 0:
            nueva_fila = (fila + 1) % 3
            nueva_col = col
        
        fila, col = nueva_fila, nueva_col
    
    return cuadrado

def verificar_cuadrado_magico(cuadrado):
    """Verifica que todas las sumas den 15"""
    suma_objetivo = 15
    
    # Verificar filas
    for i in range(3):
        if sum(cuadrado[i]) != suma_objetivo:
            return False
    
    # Verificar columnas
    for j in range(3):
        if sum(cuadrado[i][j] for i in range(3)) != suma_objetivo:
            return False
    
    # Verificar diagonales
    if sum(cuadrado[i][i] for i in range(3)) != suma_objetivo:
        return False
    if sum(cuadrado[i][2-i] for i in range(3)) != suma_objetivo:
        return False
    
    return True

def mostrar_resultado(cuadrado):
    """Muestra el cuadrado y verifica las sumas"""
    print("CUADRADO MÁGICO 3x3:")
    for fila in cuadrado:
        print(fila)
    
    # Mostrar verificación
    print("\nVerificación de sumas:")
    for i in range(3):
        print(f"Fila {i+1}: {sum(cuadrado[i])}")
    
    for j in range(3):
        suma_col = sum(cuadrado[i][j] for i in range(3))
        print(f"Columna {j+1}: {suma_col}")
    
    diag1 = sum(cuadrado[i][i] for i in range(3))
    diag2 = sum(cuadrado[i][2-i] for i in range(3))
    print(f"Diagonal principal: {diag1}")
    print(f"Diagonal secundaria: {diag2}")
    
    es_valido = verificar_cuadrado_magico(cuadrado)
    print(f"\n¿Es válido? {'✓ SÍ' if es_valido else '✗ NO'}")

# Programa principal
if __name__ == "__main__":
    print("GENERADOR DE CUADRADO MÁGICO 3x3")
    print("Método Siamés - Todas las sumas = 15")
    print("="*35)
    
    cuadrado = generar_cuadrado_magico_3x3()
    mostrar_resultado(cuadrado)