import numpy as np

A = np.array([[5, 6, 9],
              [15, 12, 6],
              [9, 12, 13],
              [9, 15, 13]])  # Corregí la coma faltante

B = np.array([[5, 9, 9],
              [15, 6, 8],
              [9, 12, 15],
              [30, 25, 14]])

def sumaMatrices(mat1, mat2):
    if mat1.shape != mat2.shape:
        print("Las matrices no son del mismo tamaño")
        return None
    
    MatSuma = np.zeros((len(mat1), len(mat1[0])))
    for i in range(len(mat1)):
        for j in range(len(mat1[0])):
            MatSuma[i][j] = mat1[i][j] + mat2[i][j]
    return MatSuma

def restaMatrices(mat1, mat2):
    if mat1.shape != mat2.shape:
        print("Las matrices no son del mismo tamaño")
        return None
    
    MatResta = np.zeros((len(mat1), len(mat1[0])))
    for i in range(len(mat1)):
        for j in range(len(mat1[0])):
            MatResta[i][j] = mat1[i][j] - mat2[i][j]
    return MatResta

def multiMatrices(mat1, mat2):
    if len(mat1[0]) != len(mat2):
        print("Las matrices no son multiplicables")
        return None
    
    MatMulti = np.zeros((len(mat1), len(mat2[0])))
    
    for i in range(len(mat1)):
        for j in range(len(mat2[0])):
            for k in range(len(mat2)):
                MatMulti[i][j] += mat1[i][k] * mat2[k][j]
    return MatMulti

# Probemos las funciones
print("=== SUMA DE MATRICES ===")
resultado_suma = sumaMatrices(A, B)
print(resultado_suma)

print("\n=== RESTA DE MATRICES ===")
resultado_resta = restaMatrices(A, B)
print(resultado_resta)

print("\n=== MULTIPLICACIÓN DE MATRICES ===")
# Para multiplicar A (4x3) y B (4x3), necesitamos que B sea 3x4 (transpuesta)
B_transpuesta = B.T  # Transponemos B para que sea 3x4
print("B transpuesta:")
print(B_transpuesta)
print("\nA x B^T:")
resultado_multi = multiMatrices(A, B_transpuesta)
print(resultado_multi)

def ProdEscalar(mat1, num):
    MatMultiEscalar = np.zeros((len(mat1), len(mat1[0])))
    for i in range(len(mat1)):
        for j in range(len(mat1[0])):
            MatMultiEscalar[i][j] = mat1[i][j] * num
    return MatMultiEscalar

print("\n=== PRODUCTO ESCALAR ===")
resultado_escalar = ProdEscalar(A, 5)
print(resultado_escalar)
