import numpy as np
v1 = np.array([5, 6, 8, 9, 12, 35, 56, 100])
v2 = np.array([23, 45, 56, 89, 64, 36, 25, 49])

#suma de Vectores
def sumaVectores(vec1, vec2):
    VectSuma = np.zeros(len(vec1))

    if(len(vec1) == len(vec2)):
        for i in range(len(vec1)):
            VectSuma[i] = vec1[i] + vec2[i]
        return VectSuma
    else:
        print("Los vectores no pueden sumar, no son de la mismo tamaño")

#Resta de vectores
def restaVectores(vec1, vec2):
    VectResta = np.zeros(len(vec1))
    if(len(vec1) == len(vec2)):
        for i in range(len(vec1)):
            VectResta[i] = vec1[i] - vec2[i]
        return VectResta
    else:
        print("Los vectores no pueden restarse, no son del mismo tamaño")

#Multiplicacion de vectores
def multiVectores(vec1, vec2):
    VectMulti = np.zeros(len(vec1))
    if(len(vec1) == len(vec2)):
        for i in range(len(vec1)):
            VectMulti[i] = vec1[i] * vec2[i]
        return VectMulti
    else:
        print("Los vectores no pueden multiplicarse, no son del mismo tamaño")


#multiplicacion por un escalar
def multiEscalar(vec1, num):
    VectMultiEscalar = np.zeros(len(vec1))
    for i in range(len(vec1)):
        VectMultiEscalar[i] = vec1[i] * num
    return VectMultiEscalar



print ("Multiplicacion por un Vector ", multiEscalar(v1, 5))
print ("Utilizando numpy ", v1 * 5)
print ("Suma de vectores ", sumaVectores(v1, v2))
print ("Utilizando numpy ", v1 + v2)
print ("Resta de vectores ", restaVectores(v1, v2))
print ("Utilizando numpy ", v1 - v2)
print ("Multiplicacion de vectores ", multiVectores(v1, v2))
print ("Utilizando numpy ", v1 * v2)
